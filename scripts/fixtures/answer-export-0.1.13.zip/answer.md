# Answer Export 合成原文

完整原文保留，公式 $\nu$。

$$\frac{1}{2}$$

![离线图](images/image-001.png)

| 步骤 | 说明 |
|---|---|
| A | 完整保留 |
