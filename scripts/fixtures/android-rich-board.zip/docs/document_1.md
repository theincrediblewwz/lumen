<!-- lumen-document/v1
{"schema":"lumen-document/v1","kind":"pdf","original":{"path":"docs/asset_4b8f1fa8ab1063e8b36f60b8a891417fbd416c023d7a7bd3c0f043d7665d2b41.pdf","sha256":"4b8f1fa8ab1063e8b36f60b8a891417fbd416c023d7a7bd3c0f043d7665d2b41","size":55468,"media_type":"application/pdf"},"images":{},"pages":2,"extraction":"ready"}
-->

## 第 1 页

图文学习资料
PDF text extraction: evidence and understanding.
数学与证据
a2 + b2
 = 1
c2
正文中的中文、公式和图片都应保留。

## 第 2 页

第二页
Page two: 原始资料完整保留。