<!-- lumen-document/v1
{"schema":"lumen-document/v1","kind":"pdf","original":{"path":"docs/asset_2d4655a91c2b7739103e79c24415d01396f28dbc50d86fd1c71778936d95b770.pdf","sha256":"2d4655a91c2b7739103e79c24415d01396f28dbc50d86fd1c71778936d95b770","size":56360,"media_type":"application/pdf"},"images":{},"pages":2,"extraction":"ready"}
-->

## 第 1 页

图文学习资料
PDF text extraction: evidence and understanding.
数学与证据
a2 + b2
 = 1
c2
正文中的中文、公式和图片都应保留。

## 第 2 页

第二页
Page two: 原始资料完整保留。