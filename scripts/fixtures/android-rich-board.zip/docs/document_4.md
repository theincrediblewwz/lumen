<!-- lumen-document/v1
{"schema":"lumen-document/v1","kind":"markdown_bundle","original":{"path":"docs/asset_d9c27d773780aa73f6698a89d91d191c69b097f6766278e4d2067b2048f635c3.zip","sha256":"d9c27d773780aa73f6698a89d91d191c69b097f6766278e4d2067b2048f635c3","size":10284,"media_type":"application/zip"},"images":{"images/image-001.png":{"path":"docs/asset_114eb6bb3a39f9b8c37cc01fcfc51d65dc2ff8c5aceab400e7d47eaa42311452.png","sha256":"114eb6bb3a39f9b8c37cc01fcfc51d65dc2ff8c5aceab400e7d47eaa42311452","size":9314,"media_type":"image/png"}},"pages":0,"extraction":"ready"}
-->

# 图文阅读验收

关键证据：图片、公式与原文应一起保存。

行内公式 $x_i^2$，块公式：

$$\frac{a^2+b^2}{c^2}=1$$

![学习示意图](images/image-001.png)

![第二幅图][ref]

[ref]: images/image-001.png

<table><thead><tr><th>证据</th><th>示意图</th></tr></thead><tbody><tr><td>图文表格</td><td><img src="images/image-001.png"></td></tr></tbody></table>

<math xmlns="http://www.w3.org/1998/Math/MathML"><mfrac><mi>a</mi><mi>b</mi></mfrac></math>

<script>throw new Error("must not execute")</script><img src="https://example.invalid/private.png">